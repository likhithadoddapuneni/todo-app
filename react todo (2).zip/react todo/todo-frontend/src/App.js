import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [todos, setTodos] = useState([]);
  const [input, setInput] = useState('');
  const [editId, setEditId] = useState(null); // Track edit state

  useEffect(() => {
    fetchTodos();
  }, []);

  const fetchTodos = async () => {
    const res = await axios.get('http://localhost:5000/todos');
    setTodos(res.data);
  };

  const addOrUpdateTodo = async () => {
    if (!input) return;

    if (editId) {
      // Update existing Todo
      const res = await axios.put(`http://localhost:5000/todos/${editId}`, { text: input });
      setTodos(todos.map(todo => (todo._id === editId ? res.data : todo)));
      setEditId(null);
    } else {
      // Add new Todo
      const res = await axios.post('http://localhost:5000/todos', { text: input });
      setTodos([...todos, res.data]);
    }

    setInput('');
  };

  const deleteTodo = async (id) => {
    await axios.delete(`http://localhost:5000/todos/${id}`);
    setTodos(todos.filter(todo => todo._id !== id));
  };

  const startEdit = (todo) => {
    setInput(todo.text);
    setEditId(todo._id);
  };

  const cancelEdit = () => {
    setInput('');
    setEditId(null);
  };

  return (
    <div className="todo-container">
      <h2>To-Do App</h2>

      <div className="todo-input">
        <input
          type="text"
          placeholder="Enter new todo"
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button onClick={addOrUpdateTodo}>
          {editId ? 'Update' : 'Add'}
        </button>
        {editId && (
          <button onClick={cancelEdit} style={{ backgroundColor: '#888', marginLeft: '5px' }}>
            Cancel
          </button>
        )}
      </div>

      <ul className="todo-list">
        {todos.map(todo => (
          <li key={todo._id}>
            {todo.text}
            <div>
              <button onClick={() => startEdit(todo)} style={{ marginRight: '5px', backgroundColor: '#ffc107' }}>
                Edit
              </button>
              <button onClick={() => deleteTodo(todo._id)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
